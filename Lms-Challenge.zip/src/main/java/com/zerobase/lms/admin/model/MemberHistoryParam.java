package com.zerobase.lms.admin.model;

import lombok.Data;

@Data
public class MemberHistoryParam extends CommonParam {
    String userId;
}
