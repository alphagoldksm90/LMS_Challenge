package com.zerobase.lms.admin.model;

import lombok.Data;

@Data
public class MemberParam extends CommonParam {
    String userId;
}
