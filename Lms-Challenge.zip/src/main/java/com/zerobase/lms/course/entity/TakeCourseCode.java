package com.zerobase.lms.course.entity;

public interface TakeCourseCode {
    String STATUS_REQ = "REQ"; // 수강신청
    String STATUS_COMPLETE = "COMPLETE"; // 결제완료
    String STATUS_CANCEL = "CANCEL"; // 수강 취소
}
